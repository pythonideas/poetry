def demo():
    print("util")

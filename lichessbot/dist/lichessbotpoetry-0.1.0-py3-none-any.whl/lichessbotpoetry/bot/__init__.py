import chess

def demo():
    board = chess.Board()

    print(board)
